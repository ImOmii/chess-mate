package com.mygdx.game.rules;


public interface Movable{
    public boolean move (int row, int col);
}