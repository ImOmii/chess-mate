package com.mygdx.game.models;

public class InvalidMoveExcpeption extends Exception {

}
